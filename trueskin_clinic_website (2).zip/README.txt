TRUESKIN CLINIC — FREE WEBSITE
==============================

The website is contained in index.html.

To publish it for free:
1. Create a free GitHub account at github.com.
2. Create a new PUBLIC repository named: trueskin-clinic
3. Upload index.html.
4. In the repository, open Settings > Pages.
5. Under Build and deployment, choose "Deploy from a branch".
6. Select the main branch and the root folder, then Save.
7. GitHub will provide a free website address.

IMPORTANT:
- Verify all doctor qualifications, clinic details, phone number, address and service claims before publishing.
- Replace the "AB" placeholder with an authorised professional photograph if desired.
- The website currently uses a tel: call button and WhatsApp link.
